<?php
// Example GitHub snippet
add_action('wp_footer', 'wsu_github_example_snippet');
function wsu_github_example_snippet() {
    // Your code here
    echo '<!-- GitHub snippet loaded -->';
}